
#include "openib_common\mem.c"
#include "openib_common\util.c"
#include "openib_common\cq.c"
#include "openib_common\qp.c"
#include "openib_common\ib_extensions.c"
