/* 
 * Include all files that are not in children directories.
 */

#include "../common/dat_api.c"
#include "../common/dat_dictionary.c"
#include "../common/dat_dr.c"
#include "../common/dat_init.c"
#include "../common/dat_sr.c"
#include "../common/dat_strerror.c"
#include "windows/dat_osd.c"
