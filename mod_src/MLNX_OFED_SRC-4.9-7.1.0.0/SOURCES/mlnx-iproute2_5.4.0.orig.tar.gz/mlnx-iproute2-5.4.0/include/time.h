#include_next <time.h>

#ifndef CLOCK_BOOTTIME
#define CLOCK_BOOTTIME                 7
#endif

#ifndef CLOCK_TAI
#define CLOCK_TAI                     11
#endif
