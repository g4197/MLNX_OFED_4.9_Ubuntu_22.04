#ifdef HAVE_XTABLES_VERSION_H
#include_next <xtables-version.h>
#endif
