/*************************************************************************/
/* OPARI Version 1.1                                                     */
/* Copyright (C) 2001                                                    */
/* Forschungszentrum Juelich, Zentralinstitut fuer Angewandte Mathematik */
/*************************************************************************/

#ifndef OPARI_OMP_H
#define OPARI_OMP_H

  #ifdef _OPENMP
    #include <omp.h>
  #endif


#endif
