
#ifndef IPM_ENV_H_INCLUDED
#define IPM_ENV_H_INCLUDED

int ipm_get_env(void);

#endif /* IPM_ENV_H_INCLUDED */
