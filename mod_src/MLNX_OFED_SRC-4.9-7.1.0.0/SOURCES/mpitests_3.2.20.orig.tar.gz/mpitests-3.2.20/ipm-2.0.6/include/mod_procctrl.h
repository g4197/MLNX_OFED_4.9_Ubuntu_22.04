
#ifndef MOD_PROCCTRL_H_INCLUDED
#define MOD_PROCCTRL_H_INCLUDED

#include "ipm_modules.h"

int mod_procctrl_init(ipm_mod_t* mod, int flags);

#endif /* MOD_PROCCTRL_H_INCLUDED */
