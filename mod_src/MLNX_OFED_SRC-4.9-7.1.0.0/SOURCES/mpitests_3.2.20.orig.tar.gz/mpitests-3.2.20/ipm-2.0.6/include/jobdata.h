

void ipm_get_job_id(char *id, int len);

void ipm_get_job_user(char *user, int len);

void ipm_get_job_allocation(char *allocation, int len);

void ipm_get_mach_info(char *machi, int len);

void ipm_get_mach_name(char *machn, int len);

void ipm_get_exec_cmdline(char *cmdl, char *rpath);

void ipm_get_exec_md5sum(char *md5sum, char *rpath);
