#ifndef _LINUX_SIGNAL_BACKPORT_2_6_17
#define _LINUX_SIGNAL_BACKPORT_2_6_17

#include_next <linux/signal.h>

#define IRQF_SHARED SA_SHIRQ

#endif
