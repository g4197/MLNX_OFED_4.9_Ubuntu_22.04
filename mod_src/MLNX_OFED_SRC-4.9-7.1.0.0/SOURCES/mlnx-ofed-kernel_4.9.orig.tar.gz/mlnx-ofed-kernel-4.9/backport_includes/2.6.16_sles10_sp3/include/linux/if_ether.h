#ifndef __BACKPORT_LINUX_IF_ETHER_H_TO_2_6_21__
#define __BACKPORT_LINUX_IF_ETHER_H_TO_2_6_21__

#include_next <linux/if_ether.h>

#define ETH_FCS_LEN     4               /* Octets in the FCS             */

#endif
