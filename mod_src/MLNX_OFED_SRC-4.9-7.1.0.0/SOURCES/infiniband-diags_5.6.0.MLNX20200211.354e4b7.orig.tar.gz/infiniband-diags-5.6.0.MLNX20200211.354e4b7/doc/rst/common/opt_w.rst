.. Define the common option -w

**-w, --m_key_files <dir_path>**
	Use a unique M_key read from files for requests to spesific destination
	port. If file (or files) doesn't exist in the specified directory path,
	the utility will exit.

