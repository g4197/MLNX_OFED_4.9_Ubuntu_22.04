.. Define the common option -z

**--outstanding_smps, -o <val>**
        Specify the number of outstanding SMP's which should be issued during the scan

        Default: 2

