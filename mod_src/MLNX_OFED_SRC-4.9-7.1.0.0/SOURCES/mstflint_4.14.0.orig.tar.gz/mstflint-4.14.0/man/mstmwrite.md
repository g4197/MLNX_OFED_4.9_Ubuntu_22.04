
# NAME

mstmwrite

# SYNOPSIS

mstmwrite \<device\> \<addr\> \<value\>

# DESCRIPTION

# SEE ALSO

The full documentation for **mstmwrite** is maintained as a Texinfo
manual. If the **info** and **mstmwrite** programs are properly
installed at your site, the command

> **info mstmwrite**

should give you access to the complete manual.
